module.exports = {
  darkMode: 'class', // Enable dark mode
  content: ['./index.html', './src/**/*.{vue,js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          light: '#f0faff', // Light blue
          DEFAULT: '#3b82f6', // Primary blue
          dark: '#1e3a8a', // Darker blue
        },
        secondary: {
          light: '#ffffff', // White
          DEFAULT: '#f8fafc', // Light gray background
          dark: '#1f2937', // Gray for dark mode
        },
      },
    },
  },
  plugins: [],
};
