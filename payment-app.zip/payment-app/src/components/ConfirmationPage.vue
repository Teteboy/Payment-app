<template>
    <div class="min-h-screen flex items-center justify-center bg-gray-50">
      <div class="p-6 max-w-md w-full bg-white rounded-lg shadow-lg text-center">
        <h1 class="text-3xl font-semibold text-green-600 mb-4">Paiement Réussi 🎉</h1>
        <p class="text-lg text-gray-700">Merci pour votre transaction.</p>
        <router-link
          to="/"
          class="mt-6 inline-block bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-all"
        >
          Retour à l'accueil
        </router-link>
      </div>
    </div>
  </template>
  