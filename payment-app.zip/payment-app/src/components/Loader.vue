<template>
    <div class="flex justify-center items-center">
      <svg xmlns="http://www.w3.org/2000/svg" class="animate-spin h-12 w-12 text-blue-500" viewBox="0 0 24 24" fill="none" stroke="currentColor">
        <circle cx="12" cy="12" r="10" stroke-width="4" stroke="currentColor" fill="none"/>
      </svg>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Loader',
  };
  </script>
  