<template>
    <div class="min-h-screen bg-cover bg-center flex items-center justify-center relative" style="background-image: url('@/assets/background.jpg')">
      <!-- Overlay for better contrast -->
      <div class="absolute inset-0 bg-primary-dark bg-opacity-60"></div>
  
      <!-- Form Section -->
      <div class="relative z-10 w-full max-w-lg bg-secondary-light dark:bg-secondary-dark rounded-lg shadow-lg p-8">
        <header class="w-full flex justify-between items-center mb-4">
          <h1 class="text-lg font-bold text-primary-dark dark:text-white">Secure Pay</h1>
          <button @click="toggleDarkMode" class="p-2 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
            {{ isDarkMode ? '☀️' : '🌙' }}
          </button>
        </header>
  
        <h2 class="text-2xl font-semibold text-primary-dark dark:text-gray-100 mb-6">Entrez vos détails</h2>
        <form @submit.prevent="handleSubmit" class="space-y-6">
          <!-- Montant -->
          <div>
            <label class="block text-sm font-medium text-primary-dark dark:text-gray-200">Montant (en XAF)</label>
            <input type="number" v-model="formData.amount" placeholder="Ex: 10000" class="mt-1 input" />
            <p v-if="errors.amount" class="text-red-500 text-sm mt-1">{{ errors.amount }}</p>
          </div>
  
          <!-- Méthode de paiement -->
          <div>
            <label class="block text-sm font-medium text-primary-dark dark:text-gray-200">Méthode de Paiement</label>
            <select v-model="formData.paymentMethod" class="mt-1 input">
              <option value="" disabled>-- Sélectionnez --</option>
              <option value="mobile_money">Mobile Money</option>
              <option value="credit_card">Carte Bancaire</option>
            </select>
            <p v-if="errors.paymentMethod" class="text-red-500 text-sm mt-1">{{ errors.paymentMethod }}</p>
          </div>
  
          <!-- Informations du client -->
          <div>
            <label class="block text-sm font-medium text-primary-dark dark:text-gray-200">Nom</label>
            <input type="text" v-model="formData.name" placeholder="Votre nom" class="mt-1 input" />
            <p v-if="errors.name" class="text-red-500 text-sm mt-1">{{ errors.name }}</p>
          </div>
  
          <div>
            <label class="block text-sm font-medium text-primary-dark dark:text-gray-200">Email</label>
            <input type="email" v-model="formData.email" placeholder="email@example.com" class="mt-1 input" />
            <p v-if="errors.email" class="text-red-500 text-sm mt-1">{{ errors.email }}</p>
          </div>
  
          <div>
            <label class="block text-sm font-medium text-primary-dark dark:text-gray-200">Téléphone</label>
            <input type="tel" v-model="formData.phone" placeholder="+237 690123456" class="mt-1 input" />
            <p v-if="errors.phone" class="text-red-500 text-sm mt-1">{{ errors.phone }}</p>
          </div>
  
          <button :disabled="!isFormValid || isSubmitting" class="w-full py-3 mt-4 bg-blue-500 text-white text-lg font-medium rounded-lg border-2 border-blue-500 hover:bg-blue-700 hover:border-blue-700 disabled:bg-gray-300 disabled:border-gray-300 transition-all">
            {{ isSubmitting ? "Traitement..." : "Payer" }}
          </button>
        </form>
      </div>
    </div>
  </template>
  
  <script>
  import { ref, computed } from "vue";
  import { useRouter } from "vue-router";
  
  export default {
    setup() {
      const router = useRouter();
  
      const formData = ref({
        amount: "",
        paymentMethod: "",
        name: "",
        email: "",
        phone: "",
      });
  
      const errors = ref({});
      const isSubmitting = ref(false);
      const isDarkMode = ref(false);
  
      const toggleDarkMode = () => {
        isDarkMode.value = !isDarkMode.value;
        document.documentElement.classList.toggle("dark", isDarkMode.value);
      };
  
      const validateForm = () => {
        errors.value = {}; // Reset errors before validation
        if (!formData.value.amount) errors.value.amount = "Montant requis.";
        if (!formData.value.paymentMethod) errors.value.paymentMethod = "Méthode de paiement requise.";
        if (!formData.value.name) errors.value.name = "Nom requis.";
        if (!formData.value.email || !/\S+@\S+\.\S+/.test(formData.value.email)) errors.value.email = "Email invalide.";
        if (!formData.value.phone || !/^\+?\d{7,15}$/.test(formData.value.phone)) errors.value.phone = "Numéro de téléphone invalide.";
      };
  
      const isFormValid = computed(() => {
        validateForm();
        return Object.keys(errors.value).length === 0;
      });
  
      const handleSubmit = async () => {
        validateForm();
        if (Object.keys(errors.value).length > 0) return;
  
        isSubmitting.value = true;
  
        setTimeout(() => {
          isSubmitting.value = false;
          router.push("/confirmation");
        }, 2000);
      };
  
      return {
        formData,
        errors,
        isSubmitting,
        isFormValid,
        toggleDarkMode,
        isDarkMode,
        handleSubmit,
      };
    },
  };
  </script>
  
  <style scoped>
  .input {
    width: 100%;
    padding: 0.75rem;
    border: 1px solid #d1d5db;
    border-radius: 0.375rem;
    background-color: #ffffff;
    transition: border-color 0.2s;
  }
  
  .input:focus {
    border-color: #3b82f6;
    outline: none;
  }
  </style>
  