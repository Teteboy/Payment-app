import { createRouter, createWebHistory } from "vue-router";
import PaymentForm from "../components/PaymentForm.vue";
import ConfirmationPage from "../components/ConfirmationPage.vue";

const routes = [
  { path: "/", component: PaymentForm },
  { path: "/confirmation", component: ConfirmationPage },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
